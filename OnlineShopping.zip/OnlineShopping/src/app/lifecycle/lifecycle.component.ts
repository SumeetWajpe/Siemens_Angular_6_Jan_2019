import { Component, OnInit, OnChanges, AfterViewChecked, OnDestroy, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-lifecycle',
  templateUrl: './lifecycle.component.html',
  styleUrls: ['./lifecycle.component.css']
})
export class LifecycleComponent implements OnInit,OnChanges,AfterViewChecked,OnDestroy {
@Input() message:string="";

  constructor() {
    console.log('Inside constructor !' + this.message);
   }

  ngOnInit() {
    console.log('Inside NgOnInit !' + this.message);
  }
  ngOnChanges(theChanges:SimpleChanges){

    console.log('Inside ngOnChanges !'+this.message);

    for(let prop  in theChanges){
    console.log(` Current Value :${theChanges[prop].currentValue}, Previous Value : ${theChanges[prop].previousValue}`);
    }
  }
  ngAfterViewChecked(){
    console.log('Inside ngAfterViewChecked !');
  }
  ngOnDestroy(){
    console.log('Clean Up !');
  }

}
