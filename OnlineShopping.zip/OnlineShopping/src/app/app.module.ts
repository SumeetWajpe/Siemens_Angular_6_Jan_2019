import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material';

import { AppComponent } from './app.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { ProductComponent } from './product/product.component';
import {FormsModule} from '@angular/forms';
import { QuantityPipe } from './quantity.pipe';
import { CourseComponent } from './course/course.component';
import { CourseService } from './course/course.service';
import { PostsComponent } from './posts/posts.component';
import {PostsService} from './posts/posts.service';
import {RouterModule,Routes} from '@angular/router';
import { PostDetailsComponent } from './post-details/post-details.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGaurdGuard } from './auth-gaurd.guard';
import { UserService } from './user.service';
import { AgGridModule } from 'ag-grid-angular';
import { PostAggridComponent } from './post-aggrid/post-aggrid.component';
import { HighlightDirective } from './highlight.directive';
import { LifecycleComponent } from './lifecycle/lifecycle.component';
import { UselifecycleComponent } from './uselifecycle/uselifecycle.component';
import {ProductService} from './product/product.service';

// const routes:Routes = [
// {path:'',component:ShoppingCartComponent},
// {path:'posts',component:PostsComponent},
// {path:'courses',component:CourseComponent},
// {path:'postdetails/:id',component:PostDetailsComponent},
// {path:'**',redirectTo:'/posts'}
// ];


const routes:Routes = [
  {path:'',component:LoginComponent}, 
  {path:'dashboard',
  component:DashboardComponent,
  children:[
    {path:'',component:ShoppingCartComponent},
    {path:'posts',component:PostsComponent},
    {path:'postdetails/:id',component:PostDetailsComponent},
   {path:'courses',component:CourseComponent},
    {path:'postsusinggrid',component:PostAggridComponent}

  ]
   // {path:'',component:UselifecycleComponent},
  ,canActivate:[AuthGaurdGuard]
}

  ];

@NgModule({
  declarations: [
    AppComponent,
    ShoppingCartComponent,
    ProductComponent,
    QuantityPipe,
    CourseComponent,
    PostsComponent,
    PostDetailsComponent,
    LoginComponent,
    DashboardComponent,
    PostAggridComponent,
    HighlightDirective,
    LifecycleComponent,
    UselifecycleComponent
  ],
  imports: [
    BrowserModule,FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    AgGridModule.withComponents([]),
    BrowserAnimationsModule,
    MatCheckboxModule
  ],
  providers: [CourseService,ProductService,PostsService,UserService,AuthGaurdGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
