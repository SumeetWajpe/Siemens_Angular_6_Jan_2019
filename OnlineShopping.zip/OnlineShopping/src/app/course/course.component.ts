import { Component, OnInit } from '@angular/core';
import { CourseService } from './course.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
  //,  providers:[CourseService] // component level injection !
})
export class CourseComponent implements OnInit {

  courseToBeAdded:string="";
    courseReceived:string="";
    
    
    constructor(public servObj:CourseService){
     
    }

    AddCourse(){
        this.servObj.addNewCourse(this.courseToBeAdded);
    }
    GetCourse(){
        this.courseReceived = this.servObj.getRandomCourse();
    }
  ngOnInit() {
  }

}
