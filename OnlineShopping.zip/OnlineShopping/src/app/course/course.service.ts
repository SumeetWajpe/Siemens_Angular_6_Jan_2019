export class CourseService{
    listOfCourses:string[] = ['React','Node','Angular'];

    getRandomCourse():string{
        return this.listOfCourses[Math.floor(Math.random() * this.listOfCourses.length)]
    }

    getAllCourses():string[]{
            return this.listOfCourses;
    }

     addNewCourse(newCourse:string){
         this.listOfCourses.push(newCourse);
     }
}