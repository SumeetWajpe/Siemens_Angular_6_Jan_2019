import { Component, OnInit, ViewChild } from '@angular/core';
import {PostsService} from '../posts/posts.service';
import { Post } from '../posts/posts.model';
import { AgGridNg2 } from 'ag-grid-angular';

@Component({
  selector: 'app-post-aggrid',
  templateUrl: './post-aggrid.component.html',
  styleUrls: ['./post-aggrid.component.css']
})
export class PostAggridComponent implements OnInit {

   @ViewChild('agGrid')  agGrid:AgGridNg2;
  allPostsData:Post[] =[];
  columnsDef=[
    {headerName:'Id',field:'id',resizable:false,checkboxSelection:true},
    {headerName:'Title',field:'title',resizable:true,sortable:true,filter:true},
    {headerName:'Body',field:'body',resizable:true,sortable:true,filter:true}
  ];
  constructor(private postsServObj:PostsService) { }

  ngOnInit() {
    this.postsServObj.getAllPosts().subscribe(
      r => {
          this.allPostsData = r;
          this.postsServObj.reponseposts = r;
      }
    )
  }

  GetSelectedRows(){
    // show the selected rows !
      let selectedRows= this.agGrid.api.getSelectedNodes();

      let selectedData = selectedRows.map(node => node.data);

      let data_string = selectedData.map(node => node.id + " " + node.title)

      console.log('Selected Rows : ' +  data_string)

  }

}
