import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostAggridComponent } from './post-aggrid.component';

describe('PostAggridComponent', () => {
  let component: PostAggridComponent;
  let fixture: ComponentFixture<PostAggridComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostAggridComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostAggridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
