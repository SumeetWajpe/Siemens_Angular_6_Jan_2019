import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Post } from '../posts/posts.model';
import {PostsService} from '../posts/posts.service';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {
  public postId:number;
  public thePost:Post = new Post();
  constructor(private currRoute:ActivatedRoute,
    private servObj:PostsService) { }
  ngOnInit() {
    this.currRoute.params.subscribe(
      p => {
          this.postId = p['id'];
          var allPosts = this.servObj.reponseposts;
           var theIndex = allPosts.findIndex( 
              (currPost:any) => currPost.id == this.postId 
          );
          this.thePost = allPosts[theIndex];
      } 
)
  }

}
