import { Component, OnInit } from '@angular/core';
import {PostsService}from './posts.service';
import { Post } from './posts.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  allPosts:Post[] = [];

  // Using Observable
  constructor(private postServObj:PostsService) {
       this.postServObj.getAllPosts().subscribe((response)=>{
         this.allPosts = response;
         this.postServObj.reponseposts = response;
        }
        )
   }
// using promises
// constructor(private postServObj:PostsService) {
// let thePromise =  this.postServObj.getAllPosts();
// thePromise.then(
//   function(response){
//         console.log('Promise resolved !')
//         console.log(response);
//   }
// )
// }

  ngOnInit() {
  }

}
