import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uselifecycle',
  templateUrl: './uselifecycle.component.html',
  styleUrls: ['./uselifecycle.component.css']
})
export class UselifecycleComponent implements OnInit {
  messageToBePassed:string="";
  constructor() { }

  ngOnInit() {
  }

}
