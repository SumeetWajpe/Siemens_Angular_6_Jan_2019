import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UselifecycleComponent } from './uselifecycle.component';

describe('UselifecycleComponent', () => {
  let component: UselifecycleComponent;
  let fixture: ComponentFixture<UselifecycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UselifecycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UselifecycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
