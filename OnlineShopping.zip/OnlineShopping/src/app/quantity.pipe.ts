import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'qty'
})
export class QuantityPipe implements PipeTransform {

  transform(inputvalue: any, args?: any): any {
    if(inputvalue == 0){
        return 'Items Out Of Stock !'
    }
    return inputvalue + " " + args;
  }

}
