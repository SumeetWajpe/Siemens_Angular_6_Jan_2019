import { Directive, ElementRef, Input, HostListener } from '@angular/core';

@Directive({
  selector: '[highlight]'
})
export class HighlightDirective {

    @Input() postBGColor:string = "lightblue";
  constructor(public elemRef:ElementRef) {

   }
   ngOnInit(){
        this.elemRef.nativeElement.style.backgroundColor = this.postBGColor;
        this.elemRef.nativeElement.style.border = "2px solid red";
        this.elemRef.nativeElement.style.borderRadius = "10px";
        this.elemRef.nativeElement.style.padding = "10px";
        this.elemRef.nativeElement.style.margin = "10px";
   }

    @HostListener('mouseenter') CalledOnMouseEnter(){
          this.elemRef.nativeElement.style.backgroundColor = "orange"
    }

    @HostListener('mouseleave') CalledOnMouseLeave(){
      this.elemRef.nativeElement.style.backgroundColor = this.postBGColor;
}


}
