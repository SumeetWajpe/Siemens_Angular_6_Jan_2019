import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public inputName:string="";
  public inputPassword:string="";
  constructor(private router:Router,private userObj:UserService) { }

  ngOnInit() {
  }

  HandleFormSubmit(){
    // biz logic !
    // if username & password match 
    //then redirect to dashboard

      if(this.inputName == "admin" && this.inputPassword == "admin"){
        this.userObj.setUserLoggedIn();
        this.userObj.username = "admin";
        this.router.navigate(['/dashboard']);
      }
  }

}
