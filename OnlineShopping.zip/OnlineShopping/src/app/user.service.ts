import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
private isUserLoggedIn:boolean;
public username:string="";
  constructor() { 
    this.isUserLoggedIn = false;
  }
  getUserLoggedIn(){
    return this.isUserLoggedIn;
  }
  setUserLoggedIn(){
    // api
    this.isUserLoggedIn = true;
  }
}
