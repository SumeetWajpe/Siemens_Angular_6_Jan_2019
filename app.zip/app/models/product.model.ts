export class Product{
    constructor(public title?:string,
        public rating?:number,
        public price?:number,
        public quantity?:number,
        public ImageUrl?:string
        ){

    }
}